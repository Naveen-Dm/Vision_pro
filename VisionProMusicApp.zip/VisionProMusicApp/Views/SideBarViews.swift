//
//  SideBarViews.swift
//  VisionProMusicApp
//
//  Created by Naveen Madhu on 26/02/24.
//

import SwiftUI

struct SideBarView: View {
    var body: some View {
        List (sideMenuItem) { item in
            NavigationLink(value: item.self) {
                Label(item.name, systemImage: item.icon)
                    .foregroundStyle(.primary)
            }.navigationDestination(for: SideMenuItem.self) { item in
                //                    Menu item View
            }
        }.toolbar {
            ToolbarItem(placement: .topBarLeading) {
                VStack (alignment: .leading) {
                    Text("Library")
                        .font(.largeTitle)
                    Text("All Music")
                        .foregroundStyle(.tertiary)
                }
            }
            ToolbarItem {
                Button(action: {}, label: {
                    Image(systemName: "ellipsis")
                })
            }
        }
    }
}

