//
//  ContentView.swift
//  VisionProMusicApp
//
//  Created by Naveen Madhu on 04/01/24.
//

import SwiftUI
import RealityKit
import RealityKitContent

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationSplitView{
                SideBarView()
            } detail: {
    //            Album View
                AlbumsView()
            }.tabItem {
                Label("Browse", systemImage: "music.note")
            }.tag(0)
            
            Text("Favorite")
                .tabItem {
                    Label("Favorite", systemImage: "heart.fill")
                }.tag(1)
            
            Text("Playlist")
                .tabItem {
                    Label("Playlist", systemImage: "play.square.stack")
                }.tag(2)
        }
    }
}


#Preview(windowStyle: .automatic) {
    NavigationStack{
        ContentView()
    }
}


