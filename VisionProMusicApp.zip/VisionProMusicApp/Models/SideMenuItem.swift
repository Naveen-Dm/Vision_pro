//
//  SideMenuItem.swift
//  VisionProMusicApp
//
//  Created by Naveen Madhu on 26/02/24.
//
import Foundation

struct SideMenuItem: Identifiable, Hashable {
    var id = UUID()
    var name: String
    var icon: String
}

let sideMenuItem: [SideMenuItem] = [
    SideMenuItem(name: "Recent Added", icon: "clock"),
    SideMenuItem(name: "Artists", icon: "music.mic"),
    SideMenuItem(name: "Albums", icon: "square.stack"),
    SideMenuItem(name: "Songs", icon: "music.note"),
    SideMenuItem(name: "Made For You", icon: "person.crop.square"),
]
